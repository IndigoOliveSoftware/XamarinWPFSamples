﻿using System;

using Xamarin.Forms;

namespace $safeprojectname$ {
    public partial class AboutPage : ContentPage {
        public AboutPage() {
            InitializeComponent();
        }
    }
}
