﻿In order to build an app for Android using Xamarin, if you have long directory names you will need to do the following:

Map a Network Drive to your local folder $safeprojectname$